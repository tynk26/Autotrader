# FILE: app/indicators_core.py
from dataclasses import dataclass
from typing import List, Optional, Tuple

@dataclass
class Candle:
    time: int        # epoch seconds (ascending)
    open: float
    high: float
    low: float
    close: float
    volume: float

def resample_ohlc(bars_1m: List[Candle], ratio: int) -> List[Candle]:
    out: List[Candle] = []
    buf: List[Candle] = []
    for b in bars_1m:
        buf.append(b)
        if len(buf) == ratio:
            o = buf[0]
            h = max(x.high for x in buf)
            l = min(x.low for x in buf)
            c = buf[-1]
            v = sum(x.volume for x in buf)
            out.append(Candle(time=o.time, open=o.open, high=h, low=l, close=c.close, volume=v))
            buf = []
    return out

def detect_fractals(candles: List[Candle], left: int = 2, right: int = 2) -> Tuple[List[int], List[int]]:
    H = [c.high for c in candles]
    L = [c.low for c in candles]
    n = len(candles)
    swing_highs, swing_lows = [], []
    for i in range(left, n - right):
        hi, lo = H[i], L[i]
        if all(hi > H[i-k] for k in range(1, left+1)) and all(hi >= H[i+k] for k in range(1, right+1)):
            swing_highs.append(i)
        if all(lo < L[i-k] for k in range(1, left+1)) and all(lo <= L[i+k] for k in range(1, right+1)):
            swing_lows.append(i)
    return swing_highs, swing_lows

def pick_significant_swing(candles: List[Candle], swing_idxs: List[int], min_range_pct: float = 0.3) -> Optional[int]:
    if not swing_idxs:
        return None
    last = candles[-1].close
    for i in reversed(swing_idxs):
        px = candles[i].high if candles[i].high - candles[i].low >= 0 else candles[i].low
        rng_pct = abs(px - last) / max(1e-9, last) * 100.0
        if rng_pct >= min_range_pct:
            return i
    return swing_idxs[-1]

def fib_levels_between(candles: List[Candle], idx_a: int, idx_b: int):
    """Return dict { '236': price, '382': price, '500': price, '618': price, '786': price }."""
    FIBS = [0.236, 0.382, 0.5, 0.618, 0.786]
    a, b = candles[idx_a], candles[idx_b]
    hi = max(a.high, b.high)
    lo = min(a.low, b.low)
    uptrend = (b.close >= a.close) or (b.high >= a.high)
    levels = {}
    rng = hi - lo
    if rng <= 0:
        return levels, uptrend
    if uptrend:
        # low->high leg, retrace from high downward
        for r in FIBS:
            levels[str(int(r*100))] = hi - r * rng
    else:
        # high->low leg, retrace from low upward
        for r in FIBS:
            levels[str(int(r*100))] = lo + r * rng
    return levels, uptrend

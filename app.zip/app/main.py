# FILE: app/main.py

from fastapi import FastAPI
from app.routes_mtf_fib import router as mtf_router
from app.routes_history import router as history_router  # ✅ ADD THIS LINE

app = FastAPI()
print("✅ main.py loaded")

# ✅ Register all routers
app.include_router(mtf_router)
app.include_router(history_router)  # ✅ ADD THIS LINE

@app.get("/ping")
def ping():
    return {"status": "ok"}

@app.get("/debug/routes")
def list_routes():
    return [route.path for route in app.routes]

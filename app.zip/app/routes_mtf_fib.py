# FILE: app/routes_mtf_fib.py
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict
import time, httpx

from .indicators_core import Candle, resample_ohlc, detect_fractals, pick_significant_swing, fib_levels_between

print("✅ routes_mtf_fib.py loaded")  # <— add this

router = APIRouter(
    prefix="/api/mtf",
    tags=["mtf"]
)

HISTORY_URL = "http://localhost:8000/api/history"  # reuse your existing endpoint

class FibReq(BaseModel):
    symbol: str
    durationStr: str = "2 D"          # how much to pull from history
    baseBarSize: str = "1 min"        # we compute MTF off 1m for precision
    resample: int = 5                 # 1m -> 5m
    left: int = 2
    right: int = 2
    minRangePct: float = 0.3          # swing significance filter (pct of last)

class FibLevel(BaseModel):
    key: str
    price: float

class FibResp(BaseModel):
    symbol: str
    anchor_htf_idx: int
    prev_htf_idx: int
    anchor_time: int
    prev_time: int
    uptrend: bool
    levels: List[FibLevel]            # [{'key':'618','price':...}, ...]
    htf_bar_size: str = "5 min"

async def _fetch_1m(symbol: str, durationStr: str, barSize: str) -> List[Candle]:
    payload = {
        "symbol": symbol,
        "durationStr": durationStr,
        "barSize": barSize,
        "whatToShow": "TRADES",
        "useRTH": False,
    }
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.post(HISTORY_URL, json=payload)
        if r.status_code != 200:
            raise HTTPException(r.status_code, r.text)
        bars = r.json().get("bars", [])
    out: List[Candle] = []
    for b in bars:
        # server returns e.g. "2025-09-18 14:30:00"
        # parse robustly
        ts = int(time.mktime(time.strptime(b["time"], "%Y-%m-%d %H:%M:%S")))
        out.append(Candle(
            time=ts,
            open=float(b["open"]),
            high=float(b["high"]),
            low=float(b["low"]),
            close=float(b["close"]),
            volume=float(b.get("volume", 0)),
        ))
    return out

@router.post("/fib", response_model=FibResp)
async def mtf_fib(req: FibReq):
    bars_1m = await _fetch_1m(req.symbol, req.durationStr, req.baseBarSize)
    if len(bars_1m) < req.resample * 6:
        raise HTTPException(400, "Not enough bars")

    # HTF bars (e.g., 5m)
    bars_htf = resample_ohlc(bars_1m, req.resample)
    highs, lows = detect_fractals(bars_htf, left=req.left, right=req.right)

    if not highs and not lows:
        raise HTTPException(404, "No fractal swings detected")

    hi_idx = pick_significant_swing(bars_htf, highs, min_range_pct=req.minRangePct) if highs else None
    lo_idx = pick_significant_swing(bars_htf, lows, min_range_pct=req.minRangePct) if lows else None
    candidates = [i for i in [hi_idx, lo_idx] if i is not None]
    if not candidates:
        raise HTTPException(404, "No significant swing found")

    anchor_idx = max(candidates)  # most recent significant swing
    all_swings = sorted(set(highs + lows))
    prev_list = [i for i in all_swings if i < anchor_idx]
    if not prev_list:
        raise HTTPException(404, "No previous swing to form range")
    prev_idx = prev_list[-1]

    fibs, uptrend = fib_levels_between(bars_htf, prev_idx, anchor_idx)
    levels = [FibLevel(key=k, price=float(v)) for k, v in sorted(fibs.items(), key=lambda kv: float(kv[0]))]

    return FibResp(
        symbol=req.symbol,
        anchor_htf_idx=anchor_idx,
        prev_htf_idx=prev_idx,
        anchor_time=bars_htf[anchor_idx].time,
        prev_time=bars_htf[prev_idx].time,
        uptrend=uptrend,
        levels=levels,
        htf_bar_size=f"{req.resample} min",
    )

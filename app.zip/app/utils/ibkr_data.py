# FILE: app/utils/ibkr_data.py
from ib_insync import IB, Stock, util
from typing import List
from ..indicators_core import Candle
import datetime

ib = IB()
ib.connect("127.0.0.1", 7497, clientId=99)  # paper trading port

def fetch_ibkr_candles(symbol: str, durationStr="2 D", barSize="1 min") -> List[Candle]:
    contract = Stock(symbol, "SMART", "USD")
    bars = ib.reqHistoricalData(
        contract,
        endDateTime='',
        durationStr=durationStr,
        barSizeSetting=barSize,
        whatToShow='TRADES',
        useRTH=False,
        formatDate=1
    )

    out: List[Candle] = []
    for b in bars:
        out.append(Candle(
            time=int(b.date.timestamp()),
            open=b.open,
            high=b.high,
            low=b.low,
            close=b.close,
            volume=b.volume
        ))
    return out
